"""Host checks for endpoints that receive an Azure bearer token."""

from __future__ import annotations

from urllib.parse import urlsplit

HOST_SUFFIXES: dict[str, tuple[str, ...]] = {
    "search": (".search.windows.net",),
    "openai": (".openai.azure.com", ".cognitiveservices.azure.com", ".services.ai.azure.com"),
    "storage": (".blob.core.windows.net",),
    "arm": ("management.azure.com",),
}
SCOPE_KINDS = {
    "https://search.azure.com/.default": "search",
    "https://cognitiveservices.azure.com/.default": "openai",
    "https://ai.azure.com/.default": "openai",
    "https://storage.azure.com/.default": "storage",
    "https://management.azure.com/.default": "arm",
}


def _host_matches(host: str, suffix: str) -> bool:
    if not suffix.startswith("."):
        return host == suffix
    return host.endswith(suffix) and len(host) > len(suffix)


def endpoint_error(kind: str, url: object) -> str | None:
    """Why `url` must not receive a `kind` token, or None when it is an allowed Azure endpoint."""
    suffixes = HOST_SUFFIXES[kind]
    message = (f"refusing to send an Azure token: the {kind} endpoint must be an https URL "
               f"on a host ending in {' or '.join(suffixes)}")
    if not isinstance(url, str):
        return message
    try:
        parts = urlsplit(url.strip())
        port = parts.port
    except ValueError:
        return message
    host = (parts.hostname or "").lower()
    if (parts.scheme.lower() != "https" or parts.username is not None
            or parts.password is not None or port not in (None, 443)
            or not any(_host_matches(host, suffix) for suffix in suffixes)):
        return message
    return None


def require_endpoint(kind: str, url: str) -> str:
    """`url` when it may receive a `kind` token; raises ValueError otherwise."""
    error = endpoint_error(kind, url)
    if error:
        raise ValueError(error)
    return url


def require_token_target(scope: str, url: str) -> str:
    """`url` when it is an Azure host for the token `scope`; raises ValueError otherwise."""
    kind = SCOPE_KINDS.get(scope)
    if kind is None:
        raise ValueError(f"refusing to send an Azure token for an unknown scope: {scope}")
    return require_endpoint(kind, url)
