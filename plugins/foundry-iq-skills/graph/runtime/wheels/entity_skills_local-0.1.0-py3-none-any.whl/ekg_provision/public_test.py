"""Offline guards for the two public-endpoint Provision modes.

Default and private-network `apply` stay disabled. The only live foundation
apply paths are these two modes, and both leave Search, Storage and OpenAI
reachable from the internet. Access is controlled by Microsoft Entra and RBAC,
with local keys and Shared Key disabled:

- public-test (`PublicTestSpec`) is a temporary proof that uses synthetic data
  only. Ingress is either an exact VPN IP allowlist or Entra-only.
- public-data (`PublicDataSpec`) is for genuinely public corpora, such as
  published Wikipedia articles. It is Entra-only, and one plan sets up
  everything Build needs, including an optional Content Understanding account
  for PDFs, Office files and images. It has no expiry; only public-test is
  time-limited.

`validate_public_test` rejects a spec before any Azure call, so planner,
backends, RBAC, smoke and renderers all share one set of rules. See
docs/provision.md and docs/architecture.md.
"""

from __future__ import annotations

import ipaddress
import re
from datetime import datetime, timedelta, timezone

from ekg_core.content_understanding import ACCOUNT_NAME_PATTERN as CU_ACCOUNT_NAME_PATTERN
from ekg_core.models import ProvisioningSpec, PublicDataSpec, PublicTestSpec


# Public tests are temporary. The expiry is a gate and a resource tag; it doesn't delete anything.
MAX_DURATION = timedelta(hours=72)


def validate_public_test(spec: ProvisioningSpec, *, require_active: bool = True) -> None:
    test = spec.public_endpoint
    if test is None:
        return
    if spec.public_data is not None:
        if not isinstance(test, PublicDataSpec):
            raise ValueError("public_data must be a PublicDataSpec")
        # The endpoints are internet reachable, so the operator must confirm separately
        # that no internal or non-public documents are in scope.
        if test.public_data_only is not True:
            raise ValueError("public-data requires independent public-data-only acknowledgement")
        # Build's Search service calls Storage and OpenAI. Public IP firewalls don't admit
        # same-region Storage traffic, and this mode enables no trusted-service bypass, so
        # access rests on Entra/RBAC alone (docs/provision.md).
        if test.mode != "entra_only" or test.egress_ips:
            raise ValueError("public-data requires entra_only with no IP rules")
        # One approved plan covers everything Build needs: Search identity, private container,
        # role grants (ekg_provision.access.GRANTS, plus Cognitive Services User on a Content
        # Understanding account when one is named) and both model deployments.
        if spec.build_access is None or {item.role for item in spec.model_deployments} != {
            "embedding", "chat"
        }:
            raise ValueError("public-data requires identity, private container, eight roles and both models")
    elif not isinstance(test, PublicTestSpec):
        raise ValueError("public_test must be a PublicTestSpec")
    # Private networking belongs to the private-network mode, whose apply is disabled.
    if spec.network is not None:
        raise ValueError("public test cannot use private networking")
    # Synthetic proofs stay text-only. A public-data plan can create a Content Understanding
    # account for non-text files; it gets the same Entra-only public posture as OpenAI.
    if spec.public_data is None and spec.content_understanding_name is not None:
        raise ValueError("public test cannot use Content Understanding; use public-data")
    # A new resource group keeps public resources apart from everything else, lets apply
    # confirm the target was empty, and makes cleanup "delete the resource group".
    if not spec.create_resource_group:
        raise ValueError("public test requires an isolated new resource group")
    # Nothing is selected by default. Tenant, subscription and names are explicit, bound
    # into the plan ID, and checked against Azure naming rules offline.
    guid = r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}"
    for name, value, pattern in (
        ("tenant_id", test.tenant_id, guid),
        ("subscription_id", spec.target.subscription_id, guid),
        ("resource_group", spec.target.resource_group, r"[a-zA-Z0-9_.()\-]{1,90}"),
        ("location", spec.target.location, r"[a-z][a-z0-9]+"),
        ("search_name", spec.search_name, r"[a-z0-9][a-z0-9-]{0,58}[a-z0-9]"),
        ("storage_name", spec.storage_name, r"[a-z0-9]{3,24}"),
        ("openai_name", spec.openai_name, r"[a-zA-Z0-9][a-zA-Z0-9_-]{1,63}"),
        *((("content_understanding_name", spec.content_understanding_name,
            CU_ACCOUNT_NAME_PATTERN),) if spec.content_understanding_name else ()),
    ):
        if not isinstance(value, str) or not re.fullmatch(pattern, value):
            raise ValueError(f"public test requires a valid explicit {name}")
    if spec.target.resource_group.endswith("."):
        raise ValueError("public test resource group cannot end in a period")
    # Public-test endpoints are internet reachable, so they must hold synthetic data only.
    if isinstance(test, PublicTestSpec) and test.synthetic_data_only is not True:
        raise ValueError("public test requires synthetic-data-only acknowledgement")
    # The mode is always explicit. A missing IP never falls back to entra_only silently.
    if test.mode not in ("ip_allowlist", "entra_only"):
        raise ValueError("public test requires an explicit supported ingress mode")
    if not isinstance(test.egress_ips, tuple):
        raise ValueError("public test egress IPs must be a tuple")
    if test.mode == "entra_only" and test.egress_ips:
        raise ValueError("entra_only must not include IP rules; select one explicit mode")
    # ip_allowlist admits 1-4 exact VPN host addresses behind deny-default firewalls.
    # They must be canonical and globally routable so the firewall rules match the plan.
    if test.mode == "ip_allowlist" and not 1 <= len(test.egress_ips) <= 4:
        raise ValueError("ip_allowlist requires 1-4 exact VPN egress IPv4 addresses")
    if any(not isinstance(address, str) for address in test.egress_ips):
        raise ValueError("public test requires exact public IPv4 addresses")
    if len(set(test.egress_ips)) != len(test.egress_ips):
        raise ValueError("public test egress IPs must be unique")
    for address in test.egress_ips:
        try:
            parsed = ipaddress.IPv4Address(address)
        except ValueError as error:
            raise ValueError("public test requires exact public IPv4 addresses") from error
        if not parsed.is_global or str(parsed) != address:
            raise ValueError("public test requires canonical globally routable IPv4 addresses")
    # PublicDataSpec has no expiry field, so only public-test checks one.
    if isinstance(test, PublicDataSpec):
        return
    if not isinstance(test.expires_at, str) or not re.fullmatch(
        r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z", test.expires_at
    ):
        raise ValueError("public test expiry must be UTC YYYY-MM-DDTHH:MM:SSZ")
    try:
        expiry = datetime.strptime(test.expires_at, "%Y-%m-%dT%H:%M:%SZ").replace(
            tzinfo=timezone.utc
        )
    except ValueError as error:
        raise ValueError("invalid public test expiry") from error
    remaining = expiry - datetime.now(timezone.utc)
    if require_active and not timedelta(0) < remaining <= MAX_DURATION:
        raise ValueError("public test expiry must be in the next 72 hours")
