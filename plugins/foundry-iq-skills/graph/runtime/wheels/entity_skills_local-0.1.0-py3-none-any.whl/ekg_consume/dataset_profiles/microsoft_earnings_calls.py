"""Consume profile for the microsoft-earnings-calls sample dataset.

The corpus holds one transcript per Microsoft earnings call, named ``FY{yy}Q{q}.txt``. With this
profile selected (``endpoints.dataset_profile = "microsoft-earnings-calls"``), a question that names
a call ("FY24 Q4", "Q4 FY24", "FY24 Fourth Quarter") is scoped to that call's transcript, people and
company words imply the matching ontology classes, and the demo's starter questions are offered.
"""

from __future__ import annotations

import re
from typing import Any

from ekg_consume import service
from ekg_consume.profiles import DatasetProfile

_QUARTER_WORD_MAP = {
    "first": "1",
    "second": "2",
    "third": "3",
    "fourth": "4",
}
_CALL_REFERENCE = re.compile(
    r"\b(?:FY\s*(\d{2})\s*(?:Q\s*([1-4])|(First|Second|Third|Fourth)\s+Quarter)"
    r"|Q\s*([1-4])\s*FY\s*(\d{2}))\b", re.IGNORECASE)
_PERSON_CLASSES = frozenset({"Person", "People", "Employee", "Executive", "Analyst", "Speaker"})


def call_doc_filters(text: Any) -> list[str]:
    """Every call a text names ("FY24 Q4", "Q4 FY24", "FY24 Fourth Quarter", "FY24Q4.txt"), as its
    transcript file."""
    if not isinstance(text, str):
        return []
    found: list[str] = []
    for match in _CALL_REFERENCE.finditer(text):
        quarter = (match.group(2) or match.group(4)
                   or _QUARTER_WORD_MAP[match.group(3).casefold()])
        name = f"FY{match.group(1) or match.group(5)}Q{quarter}.txt"
        if name not in found:
            found.append(name)
    return found


def call_codes(call_docs: list[str]) -> str:
    return ", ".join(doc.removesuffix(".txt") for doc in call_docs)


def shorten_call_label(call_name: str) -> str:
    doc_code = next(iter(call_doc_filters(call_name)), None)
    if doc_code:
        code = doc_code.removesuffix(".txt")
        return f"{code[:4]} {code[4:]} Earnings Call Q&A"
    cleaned = call_name.strip()
    return f"{cleaned[:28].strip()} Q&A" if len(cleaned) > 28 else f"{cleaned} Q&A"


def _row_names(row: Any) -> tuple[str, str] | None:
    if not isinstance(row, dict):
        return None
    raw_a, raw_b = row.get("a"), row.get("b")
    a_n = raw_a.get("name") if isinstance(raw_a, dict) else raw_a
    b_n = raw_b.get("name") if isinstance(raw_b, dict) else raw_b
    if isinstance(a_n, str) and isinstance(b_n, str) and a_n.strip() and b_n.strip():
        return a_n.strip(), b_n.strip()
    return None


def _ranked_targets(client: Any, graph_index: str, gql: str) -> list[str]:
    """Targets of an edge type, most-connected first; empty if the query fails."""
    try:
        res = service._call_graph_search(client, graph_index, gql)
    except Exception:
        return []
    rows = res.get("value") if isinstance(res, dict) else None
    members: dict[str, set[str]] = {}
    for row in rows if isinstance(rows, list) else []:
        if names := _row_names(row):
            members.setdefault(names[1], set()).add(names[0])
    return [name for name, _ in sorted(members.items(), key=lambda kv: (-len(kv[1]), kv[0]))]


def _edge_gql(triple: tuple[str, str, str], limit: int) -> str:
    source, predicate, target = triple
    return (
        f"MATCH (a:`{source}`)-[r:`{predicate}`]->(b:`{target}`) "
        "RETURN a.name AS a, a.id AS a_id, labels(a) AS a_type, "
        f"type(r) AS predicate, b.name AS b, b.id AS b_id, labels(b) AS b_type LIMIT {limit}"
    )


class EarningsCallsProfile(DatasetProfile):
    name = "microsoft-earnings-calls"
    predicate_labels = {
        "acquiredby": "acquisitions",
        "subsidiaryof": "subsidiaries",
        "providesproduct": "products",
        "usestechnology": "technologies",
        "partnerswith": "partnerships",
        "competeswith": "competitors",
        "belongstosegment": "business segments",
        "providescloudservice": "cloud services",
        "integrateswith": "cloud integrations",
        "enablesfeature": "platform features",
        "hostsmodel": "AI models",
    }
    type_plurals = {"productservice": "products and services"}
    # Question words that name a kind of entity without naming the ontology class.
    class_hints = (
        (frozenset({"who", "whom", "whose", "executive", "executives", "exec", "execs", "analyst",
                    "analysts", "ceo", "cfo", "coo", "cto", "people", "person", "persons", "speaker",
                    "speakers", "leader", "leaders", "leadership", "employee", "employees", "manager",
                    "managers", "founder", "founders"}),
         ("Person", "People", "Employee", "Executive", "Analyst", "Speaker")),
        (frozenset({"company", "companies", "customer", "customers", "partner", "partners", "firm",
                    "firms", "competitor", "competitors", "vendor", "vendors"}),
         ("Organization", "Organisation", "Company", "Customer", "Partner")),
    )
    person_classes = _PERSON_CLASSES
    person_words = frozenset({"person", "people", "executive", "analyst", "employee"})
    starter_predicates = (
        "belongstosegment",
        "providescloudservice",
        "integrateswith",
        "enablesfeature",
        "hostsmodel",
        "acquiredby",
        "subsidiaryof",
        "partnerswith",
        "worksfor",
    )
    deprioritized_targets = frozenset({
        "metrictimeperiod",
        "revenuemetric",
        "booking",
        "unearnedrevenue",
        "seat",
        "datacenterregion",
    })

    def source_filters(self, text: Any) -> list[str]:
        return call_doc_filters(text)

    def period_seeds(self, query: str) -> list[str]:
        """The ways a graph may name the call a question names, most specific spellings first."""
        seeds: list[str] = []
        for doc in call_doc_filters(query):
            year, quarter = doc[2:4], doc[5]
            word = next(name for name, number in _QUARTER_WORD_MAP.items() if number == quarter)
            for seed in (f"FY{year} Q{quarter}", f"Q{quarter} FY{year}", f"FY{year} {word.title()} Quarter"):
                if seed not in seeds:
                    seeds.append(seed)
        return seeds

    def scope_label(self, docs: list[str]) -> str:
        return call_codes(docs)

    def mismatched_sources(self, statements: list[Any], docs: list[str]) -> list[str]:
        wanted = {doc.casefold() for doc in docs}
        return sorted({ref for statement in statements for ref in call_doc_filters(statement)
                       if ref.casefold() not in wanted})

    def scope_graph(self, docs: list[str], nodes: dict[str, dict[str, Any]],
                    edges: dict[str, dict[str, Any]], paths: list[list[str]]) -> list[str]:
        """Keep only edges with evidence from the named calls' transcripts; returns warnings.

        A node whose name names a different call than its kept evidence is reported, not renamed:
        Search may have merged entities from several calls into one node."""
        wanted = {doc.casefold() for doc in docs}

        def matches(item: Any) -> bool:
            return isinstance(item, dict) and service._source_filename(
                str(item.get("source") or "")).casefold() in wanted

        scoped = {eid: {**edge, "provenance": kept} for eid, edge in edges.items()
                  if (kept := [p for p in edge.get("provenance") or [] if matches(p)])}
        edges.clear()
        edges.update(scoped)
        kept_ids = {nid for edge in edges.values() for nid in (edge.get("from_id"), edge.get("to_id"))}
        for nid in [nid for nid in nodes if nid not in kept_ids]:
            del nodes[nid]
        links = {(edge.get("from_id"), edge.get("to_id")) for edge in edges.values()}
        paths[:] = [path for path in paths if all(nid in kept_ids for nid in path)
                    and all((a, b) in links or (b, a) in links for a, b in zip(path, path[1:]))]
        warnings = []
        mislabeled = sorted({str(node.get("name")) for node in nodes.values()
                             if "call" in str(node.get("name") or "").casefold()
                             and (named := call_doc_filters(node.get("name")))
                             and not any(doc.casefold() in wanted for doc in named)})
        if mislabeled:
            warnings.append(
                f"These graph nodes name a different call than their evidence from {call_codes(docs)}, "
                f"so Search merged entities from several calls: {', '.join(mislabeled)}. "
                "Trust the cited transcripts, not the node names.")
        if not edges:
            warnings.append(f"No graph relationships have source evidence from {call_codes(docs)}.")
        return warnings

    def discover_starters(self, descriptor: dict[str, Any], client: Any,
                          labels: list[tuple[str, str, str]], graph_index: str,
                          ) -> list[dict[str, Any]] | None:
        """Call Q&A, executive product and analyst-firm starters; None without Q&A edges."""
        qa_triple = next((t for t in labels if t[1] in {"answeredBy", "answeredQuestionFrom"}), None)
        ev_triple = next((t for t in labels if t[1] in {"askedQuestionIn", "askedIn"}), None)
        if qa_triple is None or ev_triple is None:
            return None
        qa_src, qa_pred, qa_tgt = qa_triple
        top_call_name = next(iter(_ranked_targets(client, graph_index, _edge_gql(ev_triple, 200))), None)
        top_execs = _ranked_targets(client, graph_index, _edge_gql(qa_triple, 200))[:2]
        if top_call_name is None or not top_execs:
            return []
        prod_triple = next(
            (t for t in labels if t[0] == qa_tgt
             and t[1] in {"discussedProduct", "mentionsProduct", "providesProduct"}),
            None,
        )
        firm_triple = next(
            (t for t in labels if t[0] == qa_src
             and t[1] in {"affiliatedWith", "worksFor", "memberOf"}),
            None,
        )
        exec_join = " and ".join(top_execs[:2])
        exec_label = ", ".join(top_execs[:2])
        starters: list[dict[str, Any]] = [
            {
                "id": "call-qa-mapping",
                "label": shorten_call_label(top_call_name),
                "question": (
                    f"Who asked questions in the {top_call_name}, and which "
                    f"{service._pluralize_type(qa_tgt, self)} answered each {qa_src.lower()}'s question?"
                ),
                "direct_gql": _edge_gql(qa_triple, 100),
                "doc_filter": next(iter(call_doc_filters(top_call_name)), None),
                "predicate": qa_pred,
                "source_type": qa_src,
                "target_type": qa_tgt,
            },
        ]
        if prod_triple is not None:
            starters.append({
                "id": "exec-product-strategy",
                "label": f"{exec_label} product strategy",
                "question": f"Which products and platforms did {exec_join} discuss across earnings calls?",
                "direct_gql": _edge_gql(prod_triple, 75),
                "predicate": prod_triple[1],
                "source_type": prod_triple[0],
                "target_type": prod_triple[2],
                "seed_entities": list(top_execs[:2]),
            })
        if firm_triple is not None:
            starters.append({
                "id": "analyst-firms",
                "label": "Analyst firms & questions",
                "question": "Which organizations are affiliated with the people asking questions across earnings calls?",
                "direct_gql": _edge_gql(firm_triple, 75),
                "predicate": firm_triple[1],
                "source_type": firm_triple[0],
                "target_type": firm_triple[2],
            })
        return starters

    def match_starter(self, query: str, starters: list[dict[str, Any]]) -> dict[str, Any] | None:
        """A question about who answered in a named call uses the call Q&A starter's query."""
        if call_doc_filters(query) and "answered" in query.casefold():
            return next(
                (s for s in starters if s.get("id") == "call-qa-mapping" and s.get("direct_gql")),
                None,
            )
        return None
