"""Find programs on PATH without looking in the current folder.

On Windows, ``shutil.which`` (even with an explicit ``path=``) and bare-name launches check the
current folder before PATH, so a look-alike ``az.cmd`` or ``node.exe`` there could run instead.
"""

from __future__ import annotations

import os
from pathlib import Path

_GUARD = "NoDefaultCurrentDirectoryInExePath"


def _extensions() -> list[str]:
    raw = os.environ.get("PATHEXT") or ".COM;.EXE;.BAT;.CMD"
    return [item.lower() for item in raw.split(";") if item.strip()]


def _runnable(candidate: Path) -> bool:
    return candidate.is_file() and (os.name == "nt" or os.access(candidate, os.X_OK))


def which(name: str, path: str | None = None) -> str | None:
    """Return the absolute path of ``name`` from absolute PATH entries only, or None."""
    if Path(name).is_absolute():
        return name if _runnable(Path(name)) else None
    if os.path.dirname(name):
        return None
    names = [name]
    if os.name == "nt":
        extensions = _extensions()
        names = [name] if Path(name).suffix.lower() in extensions else [name + ext for ext in extensions]
    for entry in (os.environ.get("PATH", "") if path is None else path).split(os.pathsep):
        folder = Path(entry.strip().strip('"'))
        if not entry.strip() or not folder.is_absolute():
            continue
        for item in names:
            candidate = folder / item
            if _runnable(candidate):
                return str(candidate)
    return None


def no_current_folder_lookup() -> None:
    """Stop Windows from searching the current folder for programs this process or SDKs launch by name."""
    if os.name == "nt":
        os.environ.setdefault(_GUARD, "1")
